#include "../inc/pathfinder.h"

void mx_print_path(Path *path) {
    if (!path) return;
    mx_printstr("========================================\n");
    mx_printstr("Path: ");
    mx_printstr(path->start->name);
    mx_printstr(" -> ");
    mx_printstr(path->end->name);
    mx_printstr("\nRoute: ");
    mx_printstr(path->list[0]->name);
    for (int i = 1; path->list[i]; i++) {
        mx_printstr(" -> ");
        mx_printstr(path->list[i]->name);
    }
    mx_printstr("\nDistance: ");
    for (int i = 0; path->list[i + 1]; i++) {
        int len = mx_find_len(path->list[i], path->list[i + 1]);
        char *slen = mx_itoa(len);
        mx_printstr(slen);
        if (path->list[i + 2])
            mx_printstr(" + ");
        free(slen);
    }
    if (path->list[2]) {
        mx_printstr(" = ");
        char *sum = mx_itoa(path->len);
        mx_printstr(sum);
        free(sum);
    }
    mx_printstr("\n========================================\n");
}

