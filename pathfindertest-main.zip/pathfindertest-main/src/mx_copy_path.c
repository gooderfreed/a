#include "../inc/pathfinder.h"

Path *mx_copy_path(Path *path) {
    Path *tmp = (Path *)malloc(sizeof(Path));
    tmp->list = (Unit **)malloc(sizeof(Unit) * path->list_size);
    for (int i = 0; i < path->list_size; i++) tmp->list[i] = NULL;
    tmp->end = path->end;
    tmp->start = path->start;
    tmp->len = path->len;
    int i = 0;
    for (; path->list[i]; i++) {
        tmp->list[i] = path->list[i];
    }
    return tmp;
}

