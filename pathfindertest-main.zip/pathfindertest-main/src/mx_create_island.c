#include "../inc/pathfinder.h"

Unit *mx_create_island(char* name) {
    Unit *temp = (Unit *)malloc(sizeof(Unit));

    temp->name = mx_strdup(name);
    temp->links = NULL;
    return temp;
}

