#include "../inc/pathfinder.h"

int main(int argc, char *argv[]) {
    if (argc == 1) {
        write(2, "usage: ./pathfinder [filename]\n", 32);
        exit(0);
    }
    int file = open(argv[1], O_RDONLY);
    char *line;

    mx_check_file(file, argv[1], &line);
    int size = mx_atoi(line);
    Unit_list *list = mx_create_graph(&line, file, size);

    free(line);
    mx_show_path(&list, size);
    mx_free_list(&list);

    return 0; 
}

