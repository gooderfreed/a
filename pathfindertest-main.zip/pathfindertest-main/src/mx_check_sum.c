#include "../inc/pathfinder.h"

bool mx_check_sum(int i1, int i2) {
    if (((long int)i1 + (long int)i2) > 2147483647) return false;
    return true;
}

