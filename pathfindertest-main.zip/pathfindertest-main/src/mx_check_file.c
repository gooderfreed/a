#include "../inc/pathfinder.h"

void mx_check_file(int file, char* filename, char **line) {
    if (file < 0) mx_print_error(NOT_EXIST, filename);
    if (mx_read_line(line, 1, '\n', file) < 0) mx_print_error(IS_EMPTY, filename);
    if (mx_strlen(*line) == 0) mx_print_error(NOT_VALID, "1");
    for (int i = 0; (*line)[i]; i++)
        if (!((*line)[i] > 47 && (*line)[i] < 58)) mx_print_error(NOT_VALID, "1");
}

