#include "../inc/pathfinder.h"

Unit *mx_get_elem(Unit_list **list, char *name) {
    Unit_list *tmp = *list;

    while (tmp != NULL) {
        if (mx_strcmp(tmp->island->name, name) == 0) return tmp->island;
        tmp = tmp->next;
    }
    return NULL;
}

