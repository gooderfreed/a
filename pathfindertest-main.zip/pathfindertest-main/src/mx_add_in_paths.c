#include "../inc/pathfinder.h"

void mx_add_in_paths(Path_list **paths, Path **path) {
    if ((*path)->len > (*paths)->min_len) return;

    (*paths)->min_len = (*path)->len;

    if ((*paths)->list[0])
        if ((*paths)->min_len < (*paths)->list[0]->len)
            mx_clear_paths(paths);

    int i = 0;
    while ((*paths)->list[i]) i++;
    (*paths)->list[i] = mx_copy_path(*path);
}

