#include "../inc/pathfinder.h"

Unit_list *mx_create_unit_list(char *islnd) {
    Unit_list *tmp = (Unit_list*)malloc(sizeof(Unit_list));

    tmp->island = mx_create_island(islnd);
    tmp->next = NULL;
    return tmp;
}


