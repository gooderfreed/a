#include "../inc/pathfinder.h"

void mx_print_error(int err, void *data) {
    switch (err)
    {
    case NOT_EXIST:
        write(2, "error: file ", 13);
        write(2, data, mx_strlen(data));
        write(2, " does not exist\n", 17);
        break;
    
    case IS_EMPTY:
        write(2, "error: file ", 13);
        write(2, data, mx_strlen(data));
        write(2, " is empty\n", 11);
        break;

    case NOT_VALID:
        write(2, "error: line ", 13);
        write(2, data, mx_strlen(data));
        write(2, " is not valid\n", 15);
        break;

    case DUPLICATE:
        write(2, "error: duplicate bridges\n", 26);
        break;
    
    case INVALID_NUM:
        write(2, "error: invalid number of islands\n", 34);
        break;
    
    case TOO_BIG:
        write(2, "error: sum of bridges lengths is too big\n", 42);
        break;

    default:
        break;
    }
    exit(0);
}

