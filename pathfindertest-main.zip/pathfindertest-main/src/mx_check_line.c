#include "../inc/pathfinder.h"

bool mx_check_line(char *line) {
    bool d1 = false;
    bool d2 = false;
    char *d1_p;
    char *d2_p;
    if (line == NULL) return false;
    for (int i = 0; i < mx_strlen(line); i++) {
        if (d2 && mx_isalpha(line[i])) return false;
        if (line[i] == '-') {
            if (d1) return false;
            d1 = true;
            if (!(&(line[i]) - &(line[0]))) return false;
            d1_p = &(line[i]);
        }
        if (line[i] == ',') {
            if (d2) return false;
            d2 = true;
            if ((&(line[i]) - d1_p) == 1) return false;
            d2_p = &(line[i]);
        }
    }
    if (!d1 || !d2) return false;
    if (!mx_str_is_alpha(line, d1_p)) return false;
    if (!mx_str_is_alpha(++d1_p, d2_p)) return false;

    return true;
}

