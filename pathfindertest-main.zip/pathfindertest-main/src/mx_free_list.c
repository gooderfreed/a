#include "../inc/pathfinder.h"

void mx_free_list(Unit_list **list) {
    Unit_list *d = *list;
    Unit_list *ut;
    while (d != NULL) {
        Link *u = d->island->links;
        Link *lt;
        while (u != NULL) {
            lt = u;
            u = u->next;
            free(lt);
        }
        ut = d;
        d = d->next;
        free(ut->island->name);
        free(ut->island);
        free(ut);
    }
}

