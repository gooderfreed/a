#include "../inc/pathfinder.h"

// void mx_copy(Path_list **arr1, Path_list **arr2) {
//     if (!(*arr2)->list[0]) return;
//     int i = 0;
//     int j = 0;
//     while ((*arr1)->list[i]) {
//         printf("->%i\n", i);
//         mx_print_path((*arr1)->list[i]);
//         i++;
//     }
//     while ((*arr2)->list[j]) {
//         Path *tmp = mx_copy_path((*arr2)->list[j]);
//         if (tmp) {};
//         j++; 
//     }
// }


void mx_show_path(Unit_list **list, int size) {
    Path *path = mx_create_path(size);

    Unit_list *start = *list;
    Unit_list *end;

    // Path_list *allpaths = (Path_list *)malloc(sizeof(Path_list)); 
    // allpaths->list = (Path **)malloc(sizeof(Path) * size * 3);
    // for (int i = 0; i < size*3; i++) allpaths->list[i] = NULL;
    Path_list *paths = (Path_list *)malloc(sizeof(Path_list));
    paths->list = (Path **)malloc(sizeof(Path) * size);
    for (int i = 0; i < size; i++) paths->list[i] = NULL;

    while (start != NULL) {
        end = start->next;
        while (end != NULL) {
            path->start = start->island;
            path->end = end->island;
            paths->min_len = 2147483647;
            mx_find_path(&path, start->island, &paths);
            //mx_copy(&allpaths, &paths);
            mx_print_paths(paths);
            mx_clear_paths(&paths);

            end = end->next;
        }
        start = start->next;
    }

    // mx_printstr("-----------------\n");
    // mx_print_paths(allpaths);

    free(path->list);
    free(path);

    free(paths->list);
    free(paths);
}

