#include "../inc/pathfinder.h"

void mx_link_island(Unit_list **list, char *src_name, char *dst_name, int len) {
    Unit *src = mx_get_elem(list, src_name);
    Unit *dst = mx_get_elem(list, dst_name);
    Link *tmp = src->links;

    if (!tmp) {
        src->links = mx_create_link(dst, len);
        return;
    }
    while (tmp->next) {
        if (tmp->island->name == dst->name) mx_print_error(DUPLICATE, 0);
        tmp = tmp->next;
    }
    if (tmp->island->name == dst->name) mx_print_error(DUPLICATE, 0);
    tmp->next = mx_create_link(dst, len);
}

