#include "../inc/pathfinder.h"

Path *mx_create_path(int size) {
    Path *path = (Path *)malloc(sizeof(Path));
    path->list = (Unit**)malloc(sizeof(Unit) * size);
    path->list_size = size;
    for (int i = 0; i < size; i++) path->list[i] = NULL;
    return path;
}

