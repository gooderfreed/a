#include "../inc/pathfinder.h"

void mx_del_in_path(Path **path, Unit *islnd) {
    int i = 0;

    while ((*path)->list[i] != NULL) {
        if ((*path)->list[i]->name == islnd->name) {
            if (i != 0)
                (*path)->len -= mx_find_len((*path)->list[i - 1], islnd);
            (*path)->list[i] = NULL;
            return;
        }
        i++;
    }
}

