#include "../inc/pathfinder.h"

int mx_get_len(Unit_list *list) {
    int len = 0;
    Unit_list *tmp = list;

    while (tmp != NULL) {
        tmp = tmp->next;
        len++;
    }
    return len;
}

