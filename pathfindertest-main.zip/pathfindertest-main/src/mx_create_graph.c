#include "../inc/pathfinder.h"

Unit_list *mx_create_graph(char **line,int file, int size) {
    int line_index = 2;
    Unit_list *list = NULL;

    while (mx_read_line(line, 50, '\n', file) >= 0) {
        if (!mx_check_line(*line)) mx_print_error(NOT_VALID, mx_itoa(line_index));
        char **parts1 = mx_strsplit(*line, '-');
        char **parts2 = mx_strsplit(parts1[1], ',');
        char *islnd1 = parts1[0];
        char *islnd2 = parts2[0];
        int len = mx_atoi(parts2[1]);

        if (len == 0) mx_print_error(NOT_VALID, mx_itoa(line_index));
        if (len < 0) mx_print_error(TOO_BIG, 0);
        if (mx_strcmp(islnd1, islnd2) == 0) mx_print_error(NOT_VALID, mx_itoa(line_index));

        if (!mx_search(list, islnd1)) mx_add_island(&list, islnd1);
        if (mx_search(list, islnd2) == 0)mx_add_island(&list, islnd2);

        mx_link_island(&list, islnd1, islnd2, len);
        mx_link_island(&list, islnd2, islnd1, len);

        if (size < mx_get_len(list)) mx_print_error(INVALID_NUM, 0);
        line_index++;
        free(parts1[0]);
        free(parts1[1]);
        free(parts1);
        free(parts2[0]);
        free(parts2[1]);
        free(parts2);
    }
    if (size > mx_get_len(list)) mx_print_error(INVALID_NUM, 0);
    return list;
}

