#include "../inc/pathfinder.h"

bool mx_str_is_alpha(char *start, char *end) {
    for (int i = 0; i < end - start; i++)
        if (!mx_isalpha(start[i])) return false;
    return true;
}

