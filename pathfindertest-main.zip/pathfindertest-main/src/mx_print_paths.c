#include "../inc/pathfinder.h"

void mx_print_paths(Path_list *paths) {
    int i = 0;
    while (paths->list[i] != NULL) {
        if (paths->list[i]->len == paths->min_len)
            mx_print_path(paths->list[i]);
        i++;
    }
}

