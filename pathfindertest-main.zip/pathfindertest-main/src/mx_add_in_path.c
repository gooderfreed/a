#include "../inc/pathfinder.h"

bool mx_add_in_path(Path **path, Unit *islnd) {
    int i = 0;
    while ((*path)->list[i] != NULL) {
        if ((*path)->list[i]->name == islnd->name) return false;
        i++;
    }
    if (i != 0) {
        if (!mx_check_sum((*path)->len, mx_find_len((*path)->list[i - 1], islnd))) mx_print_error(TOO_BIG, 0);
        (*path)->len += mx_find_len((*path)->list[i - 1], islnd);
    }
    (*path)->list[i] = islnd;
    return true;
}

