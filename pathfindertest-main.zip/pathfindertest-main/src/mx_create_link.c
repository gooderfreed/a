#include "../inc/pathfinder.h"

Link *mx_create_link(Unit *dst, int len) {
    Link *tmp = (Link *)malloc(sizeof(Link));

    tmp->next = NULL;
    tmp->len = len;
    tmp->island = dst;
    return tmp;
}

