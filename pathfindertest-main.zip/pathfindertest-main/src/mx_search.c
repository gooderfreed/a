#include "../inc/pathfinder.h"

bool mx_search(Unit_list *list, char *name) {
    if (list == NULL) return false;
    Unit_list *tmp = list;

    while (tmp != NULL) {
        if (mx_strcmp(tmp->island->name, name) == 0) return true;
        tmp = tmp->next;
    }
    return false;
}

