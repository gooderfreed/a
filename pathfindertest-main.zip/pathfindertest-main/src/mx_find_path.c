#include "../inc/pathfinder.h"

void mx_find_path(Path **path, Unit *islnd, Path_list **paths) {
    if ((*path)->len > (*paths)->min_len) return;
    Link *tmp = islnd->links;

    if (!mx_add_in_path(path, islnd)) return;
    if (islnd->name == (*path)->end->name) mx_add_in_paths(paths, path);

    while (tmp != NULL) {
        mx_find_path(path, tmp->island, paths);
        tmp = tmp->next;
    }
    mx_del_in_path(path, islnd);
}

