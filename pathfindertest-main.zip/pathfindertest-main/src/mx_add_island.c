#include "../inc/pathfinder.h"

void mx_add_island(Unit_list **list, char *islnd) {
    if (*list == NULL) {
        *list = mx_create_unit_list(islnd);
        return;
    }
    Unit_list *tmp = *list;

    while (tmp->next != NULL) tmp = tmp->next;
    tmp->next = mx_create_unit_list(islnd);
}

