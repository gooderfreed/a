#include "../inc/pathfinder.h"

void mx_clear_paths(Path_list **paths) {
    for (int i = 0; (*paths)->list[i]; i++) {
        free((*paths)->list[i]->list);
        free((*paths)->list[i]);
        (*paths)->list[i] = NULL;
    }
}

