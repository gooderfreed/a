#include "../inc/pathfinder.h"

int mx_find_len(Unit *u1, Unit *u2) {
    Link *tmp = u1->links;

    while (tmp) {
        if (tmp->island->name == u2->name) return tmp->len;
        tmp = tmp->next;
    }
    return -1;
}

