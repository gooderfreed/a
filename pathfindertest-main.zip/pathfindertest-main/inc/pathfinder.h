#ifndef PATHFINDER_H
#define PATHFINDER_H

#include "../libmx/inc/libmx.h"

#define NOT_EXIST 0
#define IS_EMPTY 1
#define NOT_VALID 2
#define INVALID_NUM 3
#define DUPLICATE 4
#define TOO_BIG 5

typedef struct unit_t Unit;
typedef struct link_t Link;
typedef struct unit_list_t Unit_list;
typedef struct path_t Path;
typedef struct path_list_t Path_list;

typedef struct unit_list_t {
    Unit *island;
    Unit_list *next;
}              Unit_list;


typedef struct link_t {
    int len;
    Unit *island;
    Link *next;
}              Link;


typedef struct unit_t {
    char *name;
    Link *links;
}              Unit;

typedef struct path_t {
    Unit *start;
    Unit *end;
    int len;
    int list_size;
    Unit **list;
}              Path;

typedef struct path_list_t {
    int min_len;
    Path **list;
}              Path_list;


Link *mx_create_link(Unit *dst, int len);
Unit_list *mx_create_unit_list(char *islnd);
Unit_list *mx_create_graph(char **line,int file, int size);
Unit *mx_create_island(char* name);
Unit *mx_get_elem(Unit_list **list, char *name);
Path *mx_create_path(int size);
Path *mx_copy_path(Path *path);
void mx_print_path(Path *path);
void mx_free_list(Unit_list **list);
void mx_print_paths(Path_list *paths);
void mx_clear_paths(Path_list **paths);
void mx_print_error(int err, void *data);
void mx_del_in_path(Path **path, Unit *islnd);
void mx_show_path(Unit_list **list, int size);
void mx_add_island(Unit_list **list, char *islnd);
void mx_add_in_paths(Path_list **paths, Path **path);
void mx_check_file(int file, char* filename, char **line);
void mx_find_path(Path **path, Unit *islnd, Path_list **paths);
void mx_link_island(Unit_list **list, char *src_name, char *dst_name, int len);
bool mx_isdigit(int c);
bool mx_isalpha(int c);
bool mx_check_line(char *line);
bool mx_check_sum(int i1, int i2);
bool mx_search(Unit_list *list, char *name);
bool mx_str_is_alpha(char *start, char *end);
bool mx_add_in_path(Path **path, Unit *islnd);
int mx_atoi(const char *str);
int mx_get_len(Unit_list *list);
int mx_find_len(Unit *u1, Unit *u2);

#endif

